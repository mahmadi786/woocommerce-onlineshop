<?php

interface Symfony_Filesystem_Exception_ExceptionInterface
{
}
