<?php

namespace Yoast\WP\SEO\Exceptions\Indexable;

/**
 * Class Indexable_Exception
 */
abstract class Indexable_Exception extends \Exception { }
