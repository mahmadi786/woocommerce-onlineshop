( function( $ ) {

	$( document ).ready( function( $ ) {

		$( '#restaurantz-settings-metabox-container' ).tabs();

	});

} )( jQuery );
